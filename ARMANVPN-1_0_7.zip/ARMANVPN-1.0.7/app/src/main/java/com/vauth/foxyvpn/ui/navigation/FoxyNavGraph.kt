package com.vauth.foxyvpn.ui.navigation

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.vauth.foxyvpn.FoxyVpnApp
import com.vauth.foxyvpn.ui.screens.HomeScreen
import com.vauth.foxyvpn.ui.screens.LoginScreen
import com.vauth.foxyvpn.ui.screens.LogsScreen
import com.vauth.foxyvpn.ui.screens.ServerListScreen
import com.vauth.foxyvpn.ui.screens.SettingsScreen
import com.vauth.foxyvpn.ui.screens.SplashScreen
import com.vauth.foxyvpn.ui.theme.ThemeController

object FoxyRoutes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val HOME = "home"
    const val SERVERS = "servers"
    const val SETTINGS = "settings"
    const val LOGS = "logs"
}

@Composable
fun FoxyNavGraph(
    navController: NavHostController = rememberNavController(),
    app: FoxyVpnApp,
    themeController: ThemeController,
    onRequestConnect: () -> Unit,
    onDisconnect: () -> Unit,
) {
    NavHost(
        navController = navController,
        startDestination = FoxyRoutes.SPLASH,
        enterTransition = {
            slideInHorizontally(tween(420, easing = FastOutSlowInEasing)) { it / 5 } +
                fadeIn(tween(420, easing = FastOutSlowInEasing))
        },
        exitTransition = {
            slideOutHorizontally(tween(420, easing = FastOutSlowInEasing)) { -it / 8 } +
                fadeOut(tween(280))
        },
        popEnterTransition = {
            slideInHorizontally(tween(420, easing = FastOutSlowInEasing)) { -it / 8 } +
                fadeIn(tween(420, easing = FastOutSlowInEasing))
        },
        popExitTransition = {
            slideOutHorizontally(tween(420, easing = FastOutSlowInEasing)) { it / 5 } +
                fadeOut(tween(280))
        },
    ) {
        composable(
            FoxyRoutes.SPLASH,
            exitTransition = {
                fadeOut(tween(550, easing = FastOutSlowInEasing)) +
                    scaleOut(targetScale = 1.12f, animationSpec = tween(550, easing = FastOutSlowInEasing))
            },
        ) {
            SplashScreen(
                authRepository = app.authRepository,
                onSignedIn = {
                    navController.navigate(FoxyRoutes.HOME) { popUpTo(FoxyRoutes.SPLASH) { inclusive = true } }
                },
                onNeedsLogin = {
                    navController.navigate(FoxyRoutes.LOGIN) { popUpTo(FoxyRoutes.SPLASH) { inclusive = true } }
                },
            )
        }
        composable(
            FoxyRoutes.LOGIN,
            enterTransition = {
                fadeIn(tween(600, delayMillis = 150)) +
                    scaleIn(initialScale = 0.92f, animationSpec = tween(600, delayMillis = 150, easing = FastOutSlowInEasing))
            },
        ) {
            LoginScreen(
                authRepository = app.authRepository,
                onSignedIn = {
                    navController.navigate(FoxyRoutes.HOME) { popUpTo(FoxyRoutes.LOGIN) { inclusive = true } }
                },
            )
        }
        composable(
            FoxyRoutes.HOME,
            enterTransition = {
                fadeIn(tween(600, delayMillis = 150)) +
                    scaleIn(initialScale = 0.92f, animationSpec = tween(600, delayMillis = 150, easing = FastOutSlowInEasing))
            },
        ) {
            HomeScreen(
                app = app,
                themeController = themeController,
                onRequestConnect = onRequestConnect,
                onDisconnect = onDisconnect,
                onOpenServers = { navController.navigate(FoxyRoutes.SERVERS) },
                onOpenSettings = { navController.navigate(FoxyRoutes.SETTINGS) },
            )
        }
        composable(FoxyRoutes.SERVERS) {
            ServerListScreen(
                serverListClient = app.serverListClient,
                proxyStateStore = app.proxyStateStore,
                onServerSelected = { navController.popBackStack() },
                onBack = { navController.popBackStack() },
            )
        }
        composable(FoxyRoutes.SETTINGS) {
            SettingsScreen(
                settingsStore = app.settingsStore,
                onOpenLogs = { navController.navigate(FoxyRoutes.LOGS) },
                onSignOut = {
                    onDisconnect()
                    app.tokenStore.clear()
                    app.settingsStore.clearAccountSession()
                    app.proxyStateStore.clear()
                    navController.navigate(FoxyRoutes.LOGIN) { popUpTo(0) { inclusive = true } }
                },
                onBack = { navController.popBackStack() },
            )
        }
        composable(FoxyRoutes.LOGS) {
            LogsScreen(onBack = { navController.popBackStack() })
        }
    }
}
