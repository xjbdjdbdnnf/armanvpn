package com.vauth.foxyvpn.ui.screens

import android.app.Activity
import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.vauth.foxyvpn.data.FxaAuthRepository
import com.vauth.foxyvpn.data.SessionStatus
import com.vauth.foxyvpn.ui.theme.ArmanCyan
import com.vauth.foxyvpn.ui.theme.ArmanIndigo
import com.vauth.foxyvpn.ui.theme.ArmanMagenta
import com.vauth.foxyvpn.ui.theme.ArmanNight
import com.vauth.foxyvpn.ui.theme.ArmanViolet
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private const val SESSION_RESTORE_TIMEOUT_MS = 8_000L

/** The intro always plays at least this long, even if the session restores instantly. */
private const val MIN_INTRO_MS = 3_400L

private val WORDMARK = "ARMAN".toList()

private class Particle(
    val x: Float,
    val y: Float,
    val loops: Int,
    val radius: Float,
    val phase: Float,
    val colorIndex: Int,
)

@Composable
fun SplashScreen(
    authRepository: FxaAuthRepository,
    onSignedIn: () -> Unit,
    onNeedsLogin: () -> Unit,
) {
    LaunchedEffect(Unit) {
        val startedAt = SystemClock.elapsedRealtime()
        val status = withTimeoutOrNull(SESSION_RESTORE_TIMEOUT_MS) {
            authRepository.restoreSession()
        } ?: SessionStatus.UNREACHABLE

        val remaining = MIN_INTRO_MS - (SystemClock.elapsedRealtime() - startedAt)
        if (remaining > 0L) delay(remaining)

        when (status) {
            SessionStatus.ACTIVE -> onSignedIn()
            SessionStatus.UNREACHABLE -> onSignedIn()
            SessionStatus.NEEDS_LOGIN -> onNeedsLogin()
        }
    }

    LightIconsOnDarkIntro()
    ArmanIntro()
}

/** The intro background is always dark, so keep the status/navigation bar icons light while it is visible. */
@Composable
private fun LightIconsOnDarkIntro() {
    val view = LocalView.current
    val themeIsLight = MaterialTheme.colorScheme.background.luminance() > 0.5f
    val controller = remember(view) {
        (view.context as? Activity)?.window?.let { WindowCompat.getInsetsController(it, view) }
    }
    SideEffect {
        controller?.isAppearanceLightStatusBars = false
        controller?.isAppearanceLightNavigationBars = false
    }
    DisposableEffect(controller, themeIsLight) {
        onDispose {
            controller?.isAppearanceLightStatusBars = themeIsLight
            controller?.isAppearanceLightNavigationBars = themeIsLight
        }
    }
}

@Composable
private fun ArmanIntro() {
    val logoScale = remember { Animatable(0.4f) }
    val logoDraw = remember { Animatable(0f) }
    val logoFill = remember { Animatable(0f) }
    val letterAnims = remember { List(WORDMARK.size) { Animatable(0f) } }
    val tagline = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch { logoScale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 80f)) }
        launch { logoDraw.animateTo(1f, tween(1200, easing = FastOutSlowInEasing)) }
        launch {
            delay(900)
            logoFill.animateTo(1f, tween(800))
        }
        letterAnims.forEachIndexed { index, anim ->
            launch {
                delay(1000L + index * 120L)
                anim.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 220f))
            }
        }
        launch {
            delay(1800)
            tagline.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
        }
    }

    val infinite = rememberInfiniteTransition(label = "arman-intro")
    val drift = infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14_000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift",
    )
    val orbit = infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5_200, easing = LinearEasing), RepeatMode.Restart),
        label = "orbit",
    )
    val shimmer = infinite.animateFloat(
        initialValue = -0.2f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(2_200, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "shimmer",
    )
    val loader = infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1_100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "loader",
    )
    val pulse = infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1_800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )

    val palette = remember { listOf(ArmanCyan, ArmanViolet, ArmanMagenta) }
    val particles = remember {
        val rnd = Random(11)
        List(42) {
            Particle(
                x = rnd.nextFloat(),
                y = rnd.nextFloat(),
                loops = 1 + rnd.nextInt(3),
                radius = 0.8f + rnd.nextFloat() * 2.0f,
                phase = rnd.nextFloat(),
                colorIndex = rnd.nextInt(3),
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(ArmanNight, ArmanIndigo, ArmanNight)))
            .drawBehind {
                val w = size.width
                val h = size.height
                val t = drift.value
                val angle = (2.0 * PI * t).toFloat()

                val glowA = Offset(w * (0.18f + 0.12f * sin(angle)), h * (0.16f + 0.05f * cos(angle)))
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(ArmanCyan.copy(alpha = 0.22f), Color.Transparent),
                        center = glowA,
                        radius = w * 0.85f,
                    ),
                )
                val glowB = Offset(w * (0.82f - 0.12f * sin(angle)), h * (0.86f - 0.05f * cos(angle)))
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(ArmanMagenta.copy(alpha = 0.20f), Color.Transparent),
                        center = glowB,
                        radius = w * 0.9f,
                    ),
                )

                particles.forEach { p ->
                    val y = (((p.y - t * p.loops) % 1f) + 1f) % 1f
                    val twinkle = 0.5f + 0.5f * sin(angle * p.loops + p.phase * 6.2832f)
                    val edgeFade = sin(PI.toFloat() * y).coerceIn(0f, 1f)
                    val alpha = (0.12f + 0.45f * twinkle) * edgeFade
                    drawCircle(
                        color = palette[p.colorIndex].copy(alpha = alpha),
                        radius = p.radius.dp.toPx(),
                        center = Offset(p.x * w, y * h),
                    )
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            ArmanLogo(
                modifier = Modifier.size(240.dp),
                logoScale = { logoScale.value },
                draw = { logoDraw.value },
                fill = { logoFill.value },
                orbit = { orbit.value },
                pulse = { pulse.value },
            )

            Spacer(Modifier.height(4.dp))

            ArmanWordmark(
                progress = { index -> letterAnims[index].value },
                shimmer = { shimmer.value },
            )

            Spacer(Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .width(190.dp)
                    .height(2.dp)
                    .graphicsLayer {
                        val p = tagline.value.coerceIn(0f, 1f)
                        scaleX = p
                        alpha = p
                    }
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, ArmanCyan, ArmanViolet, ArmanMagenta, Color.Transparent),
                        ),
                    ),
            )

            Spacer(Modifier.height(14.dp))

            Text(
                text = "VPN",
                modifier = Modifier
                    .padding(start = 14.dp)
                    .graphicsLayer {
                        val p = tagline.value.coerceIn(0f, 1f)
                        alpha = p
                        translationY = (1f - p) * 16.dp.toPx()
                    },
                style = TextStyle(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 14.sp,
                    color = ArmanCyan,
                ),
            )

            Spacer(Modifier.height(10.dp))

            Text(
                text = "SECURE  \u2022  PRIVATE  \u2022  FAST",
                modifier = Modifier.graphicsLayer {
                    alpha = tagline.value.coerceIn(0f, 1f) * 0.6f
                },
                style = TextStyle(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 3.sp,
                    color = Color.White,
                ),
            )
        }

        Canvas(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 56.dp)
                .width(132.dp)
                .height(4.dp)
                .graphicsLayer { alpha = tagline.value.coerceIn(0f, 1f) },
        ) {
            val radius = size.height / 2f
            drawRoundRect(
                color = Color.White.copy(alpha = 0.10f),
                cornerRadius = CornerRadius(radius, radius),
            )
            val segment = size.width * 0.38f
            val x = (size.width - segment) * loader.value
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(ArmanCyan, ArmanViolet, ArmanMagenta),
                    startX = x,
                    endX = x + segment,
                ),
                topLeft = Offset(x, 0f),
                size = Size(segment, size.height),
                cornerRadius = CornerRadius(radius, radius),
            )
        }
    }
}

@Composable
private fun ArmanLogo(
    modifier: Modifier,
    logoScale: () -> Float,
    draw: () -> Float,
    fill: () -> Float,
    orbit: () -> Float,
    pulse: () -> Float,
) {
    Canvas(modifier = modifier) {
        val s = logoScale()
        val drawProgress = draw().coerceIn(0f, 1f)
        val fillProgress = fill().coerceIn(0f, 1f)
        val pulseValue = pulse()
        val cx = size.width / 2f
        val cy = size.height / 2f
        val center = Offset(cx, cy)

        scale(scale = s, pivot = center) {
            // soft neon glow behind the shield
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ArmanCyan.copy(alpha = (0.20f + 0.18f * pulseValue) * fillProgress),
                        ArmanViolet.copy(alpha = 0.10f * fillProgress),
                        Color.Transparent,
                    ),
                    center = center,
                    radius = size.minDimension * 0.5f,
                ),
                radius = size.minDimension * 0.5f,
                center = center,
            )

            // rotating orbit ring
            if (fillProgress > 0f) {
                val ringRadius = size.minDimension * 0.46f
                drawCircle(
                    color = Color.White.copy(alpha = 0.06f * fillProgress),
                    radius = ringRadius,
                    center = center,
                    style = Stroke(width = 1.dp.toPx()),
                )
                rotate(degrees = orbit(), pivot = center) {
                    listOf(ArmanCyan, ArmanViolet, ArmanMagenta).forEachIndexed { index, color ->
                        drawArc(
                            color = color.copy(alpha = 0.9f * fillProgress),
                            startAngle = index * 120f,
                            sweepAngle = 52f,
                            useCenter = false,
                            topLeft = Offset(cx - ringRadius, cy - ringRadius),
                            size = Size(ringRadius * 2f, ringRadius * 2f),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round),
                        )
                    }
                }
                rotate(degrees = -orbit() * 1.5f, pivot = center) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.9f * fillProgress),
                        radius = 3.dp.toPx(),
                        center = Offset(cx + ringRadius * 0.8f, cy),
                    )
                }
            }

            // shield + "A" that draw themselves
            val shieldSize = size.minDimension * 0.58f
            translate(left = cx - shieldSize / 2f, top = cy - shieldSize / 2f) {
                val gradient = Brush.linearGradient(
                    colors = listOf(ArmanCyan, ArmanViolet, ArmanMagenta),
                    start = Offset.Zero,
                    end = Offset(shieldSize, shieldSize),
                )
                val shield = Path().apply {
                    moveTo(shieldSize * 0.50f, shieldSize * 0.02f)
                    lineTo(shieldSize * 0.95f, shieldSize * 0.19f)
                    lineTo(shieldSize * 0.95f, shieldSize * 0.55f)
                    cubicTo(
                        shieldSize * 0.95f, shieldSize * 0.79f,
                        shieldSize * 0.76f, shieldSize * 0.92f,
                        shieldSize * 0.50f, shieldSize * 0.99f,
                    )
                    cubicTo(
                        shieldSize * 0.24f, shieldSize * 0.92f,
                        shieldSize * 0.05f, shieldSize * 0.79f,
                        shieldSize * 0.05f, shieldSize * 0.55f,
                    )
                    lineTo(shieldSize * 0.05f, shieldSize * 0.19f)
                    close()
                }

                val strokeWidth = shieldSize * 0.045f
                val outline = shield.trimmed(drawProgress)
                drawPath(
                    path = outline,
                    brush = gradient,
                    alpha = 0.16f,
                    style = Stroke(width = strokeWidth * 3.2f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
                drawPath(
                    path = outline,
                    brush = gradient,
                    alpha = 0.35f,
                    style = Stroke(width = strokeWidth * 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
                drawPath(
                    path = outline,
                    brush = gradient,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
                if (fillProgress > 0f) {
                    drawPath(path = shield, brush = gradient, alpha = 0.20f * fillProgress)
                }

                val letterLeg = Path().apply {
                    moveTo(shieldSize * 0.31f, shieldSize * 0.70f)
                    lineTo(shieldSize * 0.50f, shieldSize * 0.27f)
                    lineTo(shieldSize * 0.69f, shieldSize * 0.70f)
                }
                val letterBar = Path().apply {
                    moveTo(shieldSize * 0.38f, shieldSize * 0.56f)
                    lineTo(shieldSize * 0.62f, shieldSize * 0.56f)
                }
                val letterProgress = ((drawProgress - 0.35f) / 0.65f).coerceIn(0f, 1f)
                val letterStroke = strokeWidth * 1.15f
                listOf(letterLeg, letterBar).forEach { part ->
                    val trimmed = part.trimmed(letterProgress)
                    drawPath(
                        path = trimmed,
                        color = ArmanCyan.copy(alpha = 0.30f),
                        style = Stroke(width = letterStroke * 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                    drawPath(
                        path = trimmed,
                        color = Color.White,
                        style = Stroke(width = letterStroke, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                }
            }
        }
    }
}

@Composable
private fun ArmanWordmark(
    progress: (Int) -> Float,
    shimmer: () -> Float,
) {
    Row(
        modifier = Modifier
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                if (progress(WORDMARK.lastIndex) > 0.9f) {
                    val band = size.width * 0.4f
                    val x = -band + (size.width + band * 2f) * shimmer()
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.85f),
                                Color.Transparent,
                            ),
                            start = Offset(x - band / 2f, 0f),
                            end = Offset(x + band / 2f, size.height * 0.35f),
                        ),
                        blendMode = BlendMode.SrcAtop,
                    )
                }
            },
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        WORDMARK.forEachIndexed { index, letter ->
            ArmanLetter(letter = letter, progress = { progress(index) })
        }
    }
}

@Composable
private fun ArmanLetter(letter: Char, progress: () -> Float) {
    Text(
        text = letter.toString(),
        modifier = Modifier.graphicsLayer {
            val p = progress()
            alpha = p.coerceIn(0f, 1f)
            translationY = (1f - p) * 70.dp.toPx()
            val letterScale = 0.5f + 0.5f * p
            scaleX = letterScale
            scaleY = letterScale
        },
        style = TextStyle(
            brush = Brush.verticalGradient(listOf(Color.White, Color(0xFFA8F3FF))),
            fontSize = 50.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 3.sp,
        ),
    )
}

private fun Path.trimmed(progress: Float): Path {
    val out = Path()
    if (progress <= 0f) return out
    val measure = PathMeasure()
    measure.setPath(this, false)
    measure.getSegment(0f, measure.length * progress.coerceIn(0f, 1f), out, true)
    return out
}
