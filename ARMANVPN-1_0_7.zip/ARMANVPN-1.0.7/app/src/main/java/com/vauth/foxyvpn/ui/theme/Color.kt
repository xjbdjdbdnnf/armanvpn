package com.vauth.foxyvpn.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val FoxSeed = Color(0xFF7C4DFF)

// ARMAN brand colors (used by the intro animation and gradients)
val ArmanCyan = Color(0xFF00E5FF)
val ArmanViolet = Color(0xFF7C4DFF)
val ArmanMagenta = Color(0xFFFF2D95)
val ArmanNight = Color(0xFF050716)
val ArmanIndigo = Color(0xFF0B0F2E)

val md_theme_light_primary = Color(0xFF5E35E8)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFE6DEFF)
val md_theme_light_onPrimaryContainer = Color(0xFF1B0063)
val md_theme_light_inversePrimary = Color(0xFFCABEFF)

val md_theme_light_secondary = Color(0xFF00829A)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFB8EEFF)
val md_theme_light_onSecondaryContainer = Color(0xFF001F26)

val md_theme_light_tertiary = Color(0xFFC2185B)
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFFFD9E6)
val md_theme_light_onTertiaryContainer = Color(0xFF3E001D)

val md_theme_light_error = Color(0xFFBA1A1A)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_errorContainer = Color(0xFFFFDAD6)
val md_theme_light_onErrorContainer = Color(0xFF410002)

val md_theme_light_background = Color(0xFFF7F5FF)
val md_theme_light_onBackground = Color(0xFF1C1B27)
val md_theme_light_surface = Color(0xFFF7F5FF)
val md_theme_light_onSurface = Color(0xFF1C1B27)
val md_theme_light_surfaceVariant = Color(0xFFE6E1F5)
val md_theme_light_onSurfaceVariant = Color(0xFF48455A)
val md_theme_light_surfaceTint = md_theme_light_primary

val md_theme_light_surfaceContainerLowest = Color(0xFFFFFFFF)
val md_theme_light_surfaceContainerLow = Color(0xFFF1EEFC)
val md_theme_light_surfaceContainer = Color(0xFFECE8F9)
val md_theme_light_surfaceContainerHigh = Color(0xFFE6E2F4)
val md_theme_light_surfaceContainerHighest = Color(0xFFE0DCEF)
val md_theme_light_surfaceBright = Color(0xFFF7F5FF)
val md_theme_light_surfaceDim = Color(0xFFDAD6E8)

val md_theme_light_outline = Color(0xFF79758B)
val md_theme_light_outlineVariant = Color(0xFFCAC5DB)
val md_theme_light_inverseSurface = Color(0xFF312F40)
val md_theme_light_inverseOnSurface = Color(0xFFF3EFFF)
val md_theme_light_scrim = Color(0xFF000000)

val md_theme_dark_primary = Color(0xFF38E8FF)
val md_theme_dark_onPrimary = Color(0xFF00363D)
val md_theme_dark_primaryContainer = Color(0xFF004F58)
val md_theme_dark_onPrimaryContainer = Color(0xFF9BF0FF)
val md_theme_dark_inversePrimary = Color(0xFF5E35E8)

val md_theme_dark_secondary = Color(0xFFC4A8FF)
val md_theme_dark_onSecondary = Color(0xFF2E1068)
val md_theme_dark_secondaryContainer = Color(0xFF45268A)
val md_theme_dark_onSecondaryContainer = Color(0xFFEBDDFF)

val md_theme_dark_tertiary = Color(0xFFFF6BC1)
val md_theme_dark_onTertiary = Color(0xFF5C0039)
val md_theme_dark_tertiaryContainer = Color(0xFF7F0F53)
val md_theme_dark_onTertiaryContainer = Color(0xFFFFD8EA)

val md_theme_dark_error = Color(0xFFFFB4AB)
val md_theme_dark_onError = Color(0xFF690005)
val md_theme_dark_errorContainer = Color(0xFF93000A)
val md_theme_dark_onErrorContainer = Color(0xFFFFDAD6)

val md_theme_dark_background = Color(0xFF070A1A)
val md_theme_dark_onBackground = Color(0xFFE6E9FF)
val md_theme_dark_surface = Color(0xFF0A0E22)
val md_theme_dark_onSurface = Color(0xFFE6E9FF)
val md_theme_dark_surfaceVariant = Color(0xFF232A47)
val md_theme_dark_onSurfaceVariant = Color(0xFFC3C9E6)
val md_theme_dark_surfaceTint = md_theme_dark_primary

val md_theme_dark_surfaceContainerLowest = Color(0xFF050716)
val md_theme_dark_surfaceContainerLow = Color(0xFF0D1229)
val md_theme_dark_surfaceContainer = Color(0xFF121833)
val md_theme_dark_surfaceContainerHigh = Color(0xFF1A2140)
val md_theme_dark_surfaceContainerHighest = Color(0xFF232B4D)
val md_theme_dark_surfaceBright = Color(0xFF2A3257)
val md_theme_dark_surfaceDim = Color(0xFF070A1A)

val md_theme_dark_outline = Color(0xFF8C93B5)
val md_theme_dark_outlineVariant = Color(0xFF2E3659)
val md_theme_dark_inverseSurface = Color(0xFFE6E9FF)
val md_theme_dark_inverseOnSurface = Color(0xFF1C1B27)
val md_theme_dark_scrim = Color(0xFF000000)

data class FoxyStatusColors(
    val connected: Color,
    val connecting: Color,
    val disconnected: Color,
)

val LightStatusColors = FoxyStatusColors(
    connected = Color(0xFF00A152),
    connecting = Color(0xFFB36B00),
    disconnected = md_theme_light_onSurfaceVariant,
)

val DarkStatusColors = FoxyStatusColors(
    connected = Color(0xFF00F5A0),
    connecting = Color(0xFFFFC44D),
    disconnected = md_theme_dark_onSurfaceVariant,
)

val LocalFoxyStatusColors = staticCompositionLocalOf { LightStatusColors }
